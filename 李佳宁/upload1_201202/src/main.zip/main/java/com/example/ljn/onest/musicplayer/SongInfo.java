package com.example.ljn.onest.musicplayer;

public class SongInfo {
    private String songName;
    private String songArtist;
    private int collect;
    private String songCover;

    public SongInfo(String songName, String songArtist, int collect, String songCover) {
        this.songName = songName;
        this.songArtist = songArtist;
        this.collect = collect;
        this.songCover = songCover;
    }

    public String getSongName() {
        return songName;
    }

    public void setSongName(String songName) {
        this.songName = songName;
    }

    public String getSongArtist() {
        return songArtist;
    }

    public void setSongArtist(String songArtist) {
        this.songArtist = songArtist;
    }

    public int getCollect() {
        return collect;
    }

    public void setCollect(int collect) {
        this.collect = collect;
    }

    public String getSongCover() {
        return songCover;
    }

    public void setSongCover(String songCover) {
        this.songCover = songCover;
    }
}
