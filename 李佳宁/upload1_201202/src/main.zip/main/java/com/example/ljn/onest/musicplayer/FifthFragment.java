package com.example.ljn.onest.musicplayer;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.ljn.onest.musicplayer.popupwindow.BottomMenu;
import com.example.ljn.onest.musicplayer.popupwindow.DownloadPopupWin;
import com.example.ljn.onest.musicplayer.popupwindow.FixTimerPopupWindow;
import com.example.ljn.onest.musicplayer.popupwindow.SharePopupWin;

import java.io.IOException;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;

import static com.example.ljn.onest.musicplayer.FifthFragment.PlayState.STATE_PAUSE;
import static com.example.ljn.onest.musicplayer.FifthFragment.PlayState.STATE_PLAYING;


public class FifthFragment extends Fragment {

    private BottomMenu menuWindow;
    private SeekBar mSeekBar;  //进度条
    private Button mPlayOrPause;
    private Button mPlayPattern;
    private Button mPlayPrevious;
    private Button mPlayNext;
    private Button mPlayList;

    private ImageView ivCover;     //封面
    private TextView mMusicName;   //歌曲名称
    private TextView mMusicArtist; //歌手名称

    private ArrayList songList = new ArrayList<SongInfo>();
    private int songsTotal;
    public final int PLAY_IN_ORDER = 0;   //顺序播放
    public final int PLAY_SINGLE = 1;    //单曲循环
    public final int PLAY_RANDOM = 2;    //随机播放
    private int playPattern;  //播放状态，0顺序，1单曲，2随机

    private Timer mTimer;
    private SeekTimeTask mTimeTask;
    private TextView tvSongCurrent;
    private TextView tvSongDuration;
    private boolean isUserTouchProgressBar;

    //    Thread tPlay;
    //    //用来区分是否需要播放音乐的枚举类型
    //    public enum IsPlay{
    //        play, notPlay
    //    }
    public enum PlayState{
        STATE_PLAYING,STATE_PAUSE,STATE_STOP
    }// 枚举元素本身由系统定义了一个表示序号的数值，从0开始顺序定义为0，1，2…。
    //// 如在weekday中，sun值为0，mon值为1，sat值为6。
    //正播放0，暂停1，停止2
    public PlayState pState ;
    private ObjectAnimator CircleAnimator;
    private ImageView mRotateCircle;
    private RequestOptions requestOptions = new RequestOptions().circleCropTransform();

    private Button btnShare;
    private Button btnDownload;
    private Button btnTimer;
    private Button btnMore;

    private Button btnCollect;

    //定义MediaPlayer属性
    private MediaPlayer mediaPlayer;
    //定义AssetManager属性
    private AssetManager assetManager;
    //定义标识当前音频的id属性
    private int curId = 1;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Nullable
    @Override
    public View onCreateView(@Nullable LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //加载内容页面的布局文件（将内容页面的XML布局文件转成View类型的对象）
        View view = inflater.inflate(R.layout.fragment_fifth_layout,//内容页面的布局文件
                container,//根视图对象
                false);//false表示需要手动调用addView方法将view添加到container
        //true表示不需要手动调用addView方法
        //获取控件对象
        findViews(view);
        //初始化播放器界面
        initView(view, 0);
        setListener();
        //加载歌曲对象
        prepareSongs();
        //MediaPlayer初始化
        initMediaPlayer();
        mRotateCircle = (ImageView)view.findViewById(R.id.iv_cover);
        //加载第一首歌的图片
        loadGlidePic(1);
        pState = STATE_PAUSE;
        CircleAnimator = ObjectAnimator.ofFloat(mRotateCircle, "rotation", 0.0f, 360.0f);
        CircleAnimator.setDuration(60000);
        CircleAnimator.setInterpolator(new LinearInterpolator());
        CircleAnimator.setRepeatCount(-1);
        CircleAnimator.setRepeatMode(ObjectAnimator.RESTART);
       // beginAnim();

        final TextView tvDes = view.findViewById(R.id.tv_description);
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            /**
             * 拖动条停止拖动的时候调用
             */
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                tvDes.setText("拖动停止");
                isUserTouchProgressBar = false;
            }

            /**
             * 拖动条开始拖动的时候调用
             */
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                tvDes.setText("开始拖动");
                isUserTouchProgressBar = true;
            }

            /**
             * 拖动条进度改变的时候调用
             */
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                tvDes.setText("当前进度：" + progress + "%");
                int touchProgress = seekBar.getProgress();  //ms
                //进度为百分比   最大长度默认100  故seekTo需要×0.01  并且×歌曲长度
                mediaPlayer.seekTo((int)(touchProgress * 0.01 * mediaPlayer.getDuration()));
                mSeekBar.setProgress(touchProgress);
                int currentPos = mediaPlayer.getCurrentPosition();
                tvSongCurrent.setText(transformToHMS(currentPos));
            }
        });

        return view;

    }

    public void loadGlidePic(int curid){
        String picName =  ((SongInfo)(songList.get(curid-1))).getSongCover();
        int DrawId = getImageId(picName);
        Glide.with(this)
                .asBitmap()
                .load(DrawId)
                .apply(requestOptions)
                .into(mRotateCircle);
    }
    /**
     * 准备歌曲文件
     */
    private void prepareSongs() {
        SongInfo s1 = new SongInfo("彩虹","周杰伦",0,"s_caihong");
        SongInfo s2 = new SongInfo("Stay With Me","Punch/灿烈",1,"s_staywithme");
        SongInfo s3 = new SongInfo("残酷月光","林宥嘉",0,"s_cankuyueguang");
        SongInfo s4 = new SongInfo("大鱼","周深",1,"s_dayu");
        SongInfo s5 = new SongInfo("发如雪","周杰伦",1,"s_faruxue");
        SongInfo s6 = new SongInfo("Kiss The Rain","李闰珉",0,"s_kisstherain");
        songList.add(s1);
        songList.add(s2);
        songList.add(s3);
        songList.add(s4);
        songList.add(s5);
        songList.add(s6);
    }

    /**
     * 初始化MediaPlayer
     */
    @RequiresApi(api = Build.VERSION_CODES.N)
    private void initMediaPlayer() {
        //MediaPlayer对象初始化
        mediaPlayer = new MediaPlayer();
        //AssetManager对象获取
        assetManager = getContext().getAssets();//getContext()!!!
                //getResourcesInternal().getAssets();
        //预加载第1首MP3
        loadMP3(1);
        loadSongInfo(1);
        //设置歌曲时长（分：秒）
        int songDuration = mediaPlayer.getDuration();
        tvSongDuration.setText(transformToHMS(songDuration));
        //线程开始运行
        //new  myThread().start();
        //给MediaPlayer注册播放完成事件监听器(顺序播放下一首)
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                //计算下一个音频文件id
                curId++;
                if(curId > 6){
                    curId = 1;
                }
                    //加载音频数据源
                loadMP3(curId);
                loadSongInfo(curId);

                //启动播放
                mediaPlayer.start();
                loadGlidePic(curId);
                beginAnim();
            }
        });
        playPattern = 0;
    }

    private void beginAnim() {
        CircleAnimator.start();
        pState = STATE_PLAYING;//状态，正播放
    }

    /**
     * 给MediaPlayer对象设置音频数据源，并加载准备好
     * @param id 待加载的音频文件id
     */
    @RequiresApi(api = Build.VERSION_CODES.N)
    private void loadMP3(int id){
        try {
            //重置MediaPlayer
            mediaPlayer.reset();
            //获取当前指定的MP3文件
            AssetFileDescriptor descriptor =
                    assetManager.openFd("0"+id+".mp3");
            //给MediaPlayer对象设置音频数据源为当前MP3
            mediaPlayer.setDataSource(descriptor);
            //加载准备好
            mediaPlayer.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    //监听器类
    public class MyListener implements View.OnClickListener {

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.btn_play_pattern://设置播放模式
                    if (playPattern==0){
                        playPattern = 1;
                        mPlayPattern.setBackgroundResource(R.drawable.repeat1);
                    }else if (playPattern ==1){
                        playPattern = 2;
                        mPlayPattern.setBackgroundResource(R.drawable.sj1);
                    }else {
                        playPattern = 0;
                        mPlayPattern.setBackgroundResource(R.drawable.re1);
                    }
                    break;
                case R.id.btn_play_pre://上一曲
                    //顺序播放
                    if (playPattern == 0){
                        //修改当前音频文件id
                        curId--;
                        if(curId < 1){
                            curId = 6;
                        }
                        loadSongInfo(curId);
                    }

                    //单曲循环
                    else if(playPattern == 1){

                    }
                    //随机播放
                    else if (playPattern == 2) {
                    curId = (curId + (int)(Math.random()*6)) % songsTotal;
                    loadSongInfo(curId);
                }

                    //加载相应的音频文件
                    loadMP3(curId);
                    //开始播放
                    mediaPlayer.start();
                    loadGlidePic(curId);
                    beginAnim();
                    //设置歌曲时长（分：秒）
                    int songDuration = mediaPlayer.getDuration();
                    tvSongDuration.setText(transformToHMS(songDuration));
                    //线程开始运行
                    //new  myThread().start();
                    //修改播放/暂停按钮的图片为“暂停播放”
                    mPlayOrPause.setBackgroundResource(R.drawable.p);
                    break;

                case R.id.btn_play_or_pause://暂停/继续播放
                    //如果正在播放，则暂停；否则，开始播放；
                    // 相应的修改背景图像
                    if(mediaPlayer.isPlaying()){//如果正在播放，则暂停
                        mediaPlayer.pause();
                        //修改当前的背景图片为“开始播放”
                        //stopTimer();
                        mPlayOrPause.setBackgroundResource(R.drawable.c);
                        loadGlidePic(curId);
                        pauseAnim();
                    } else {//没有正在播放，则开始播放
                        mediaPlayer.start();
                        //修改当前的背景图片为“暂停播放”
                        mPlayOrPause.setBackgroundResource(R.drawable.p);
                          //  startTimer();
                        //loadGlidePic(getImageId(((SongInfo)(songList.get(curId-1))).getSongCover()));
                        pauseAnim();
                    }
                    break;
                case R.id.btn_play_next://下一曲
                    //顺序播放
                    if (playPattern == 0){
                        //修改当前音频Id
                        curId++;
                        if(curId > 6){
                            curId = 1;
                        }
                        loadSongInfo(curId);
                    }

                    //单曲循环
                    else if(playPattern == 1){

                    }
                    //随机播放
                    else if (playPattern == 2) {
                        songsTotal = songList.size();
                        curId = ( curId + (int)(Math.random()*6)) % songsTotal;
                        loadSongInfo(curId);
                    }
                    //加载音频
                    loadMP3(curId);
                    //播放
                    mediaPlayer.start();
                    loadGlidePic(curId);
                    beginAnim();
                    //设置歌曲时长
                    int songDuration1 = mediaPlayer.getDuration();
                    tvSongDuration.setText(transformToHMS(songDuration1));
                    //线程开始运行
                    //new  myThread().start();
                    //startTimer();
                    //修改播放/暂停播放按钮的背景图片为“暂停播放”
                    mPlayOrPause.setBackgroundResource(R.drawable.p);
                    break;
                case R.id.btn_play_list://播放列表
                    Intent i1 = new Intent();
                    songsTotal = songList.size();
                    i1.putExtra("play_pattern", playPattern);
                    i1.putExtra("songsTotal",songsTotal);
                    i1.setClass(getContext(),SongListActivity.class);
                    startActivity(i1);
                    break;
                case R.id.btn_collect: //收藏曲目
                    int c1 = ((SongInfo)(songList.get(curId))).getCollect();
                    if (c1 == 0){
                        ((SongInfo)(songList.get(curId))).setCollect(1);
                        btnCollect.setBackgroundResource(R.drawable.h1);
                    }else {
                        ((SongInfo)(songList.get(curId))).setCollect(0);
                        btnCollect.setBackgroundResource(R.drawable.h0);
                    }
                    break;
                case R.id.btn_share: //分享
                    Intent iShare = new Intent();
                    iShare.setClass(getContext(), SharePopupWin.class);
                    startActivity(iShare);
                    break;
                case R.id.btn_download://下载
                    Intent iDld = new Intent();
                    iDld.setClass(getContext(), DownloadPopupWin.class);
                    startActivity(iDld);
                    break;
                case R.id.btn_timer://定时
                    Intent iFix = new Intent();
                    iFix.setClass(getContext(), FixTimerPopupWindow.class);
                    startActivity(iFix);
                    break;
                case R.id.btn_more: //更多
                    menuWindow = new BottomMenu(getActivity(), this);
                    menuWindow.show();
//                    Intent iMore= new Intent();
//                    iMore.setClass(getContext(), MorePopupWin.class);
//                    startActivity(iMore);
                    break;
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void pauseAnim() {
        if (pState.equals(STATE_PLAYING)){//此时正播放,转为暂停播放
            CircleAnimator.pause();
            pState = STATE_PAUSE;
        }else if (pState.equals(STATE_PAUSE)){  //此时是暂停播放，转为正播放
            if (CircleAnimator.isStarted())
                CircleAnimator.resume();
            else{
                CircleAnimator.start();
            }
            pState = STATE_PLAYING;
        }
    }
    /**
     * 加载歌曲信息界面
     */
    private void loadSongInfo(int curId) {
        //下标是顺序-1
        int c = ((SongInfo)(songList.get(curId-1))).getCollect();
        if (c == 0){
            btnCollect.setBackgroundResource(R.drawable.h0);
        }else if (c==1)
            btnCollect.setBackgroundResource(R.drawable.h1);
        String sCover = ((SongInfo)(songList.get(curId-1))).getSongCover();
        String sName = ((SongInfo)(songList.get(curId-1))).getSongName();
        String sArtist = ((SongInfo)(songList.get(curId-1))).getSongArtist();
        ivCover.setImageResource(getImageId(sCover));
        mMusicName.setText(sName);
        mMusicArtist.setText(sArtist);
        tvSongCurrent.setText("00:00");
    }

    /**
     * 根据图片名称获取图片资源id  Drawable
     * @param name
     * @return
     */
    public static int getImageId(String name){
        Class drawable = R.drawable.class;
        Field field = null;
        try {
            field =drawable.getField(name);
            int imageId = field.getInt(field.getName());
            return imageId;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 给view控件设置监听器
     */
    private void setListener() {
        MyListener myListener = new MyListener();

        mPlayPattern.setOnClickListener(myListener);
        mPlayPrevious.setOnClickListener(myListener);
        mPlayOrPause.setOnClickListener(myListener);
        mPlayNext.setOnClickListener(myListener);
        mPlayList.setOnClickListener(myListener);

        btnShare.setOnClickListener(myListener);
        btnDownload.setOnClickListener(myListener);
        btnTimer.setOnClickListener(myListener);
        btnMore.setOnClickListener(myListener);

        btnCollect.setOnClickListener(myListener);
    }

    /**
     * 获取View控件
     * @param v
     */
    private void findViews(View v) {
        ivCover = v.findViewById(R.id.iv_cover);
        mMusicName = v.findViewById(R.id.tv_music_name);
        mMusicArtist = v.findViewById(R.id.tv_music_artist);
        mSeekBar = v.findViewById(R.id.seek_bar);
        mPlayPattern = v.findViewById(R.id.btn_play_pattern);
        mPlayPrevious = v.findViewById(R.id.btn_play_pre);
        mPlayOrPause = v.findViewById(R.id.btn_play_or_pause);
        mPlayNext = v.findViewById(R.id.btn_play_next);
        mPlayList = v.findViewById(R.id.btn_play_list);

        btnShare = v.findViewById(R.id.btn_share);
        btnTimer = v.findViewById(R.id.btn_timer);
        btnDownload = v.findViewById(R.id.btn_download);
        btnMore = v.findViewById(R.id.btn_more);

        btnCollect = v.findViewById(R.id.btn_collect);
        tvSongCurrent = v.findViewById(R.id.tv_proLeft);
        tvSongDuration = v.findViewById(R.id.tv_lenRight);
    }

    /**
     * 每首歌开始播放的时候，设置计时器
     */
    private void startTimer() {
        if (mTimer == null) {
            mTimer=new Timer();
        }
        if (mTimeTask == null) {
            mTimeTask = new SeekTimeTask();
        }
        mTimer.schedule(mTimeTask,0,100);  //每隔100ms检查一次进度
    }
    private void stopTimer() {
        if (mTimeTask != null) {
            mTimeTask.cancel();
            mTimeTask=null;
        }
        if (mTimer != null) {
            mTimer.cancel();
            mTimer=null;
        }
    }

//    Timer mTimer1 =new Timer();
//    TimerTask mTimerTask1 = new TimerTask() {
//        @Override
//        public void run() {
//            if(isUserTouchProgressBar==true)//当用户正在拖动进度进度条时不处理进度条的的进度
//                return;
//            mSeekBar.setProgress(mediaPlayer.getCurrentPosition());
//        }
//    };
    //每隔10毫秒检测一下播放进度
   // mTimer1.schedule(mTimerTask, 0, 10);


    /**
     *根据歌曲播放进度，设置进度条进度
     */
    private class SeekTimeTask extends TimerTask {

        @Override
        public void run() {
            //获取当前的播放进度
            //改变播放进度，有一个条件：当用户的手触摸到进度条的时候，就不更新。
            Log.e("ljn","nihao");
            if (mediaPlayer != null && !isUserTouchProgressBar) {
                int currentPosition = mediaPlayer.getCurrentPosition(); //ms数
                //记录当前歌曲播放的百分比
                int curPosition = (int)(currentPosition*1.0f/mediaPlayer.getDuration() *100);
                if(curPosition<=100) {
                    mSeekBar.setProgress(curPosition);
                }
//                while (mSeekBar.getProgress()<= mSeekBar.getMax()) {
//                    //设置进度条当前位置为音频播放位置
//                    mSeekBar.setProgress(mediaPlayer.getCurrentPosition());
//                }
            }

        }
    }

    //设置一个线程运行进度条
    class  myThread extends Thread{
        @Override
        public void run() {
            super.run();
            //判断当前播放位置是否小于总时长
            while (mSeekBar.getProgress()<= mSeekBar.getMax()) {
                //设置进度条当前位置为音频播放位置
                mSeekBar.setProgress(mediaPlayer.getCurrentPosition());
            }
        }
    }


    /**
     * 初始化界面
     */
    private void initView(View view, int playPattern) {
        //  mQuit=(Button) this.findViewById(R.id.quit_btn);
        // mMusicPic = (SmartImageView) this.findViewById(R.id.siv_icon);
        //模式转换
        if (playPattern == PLAY_IN_ORDER) {
            mPlayPattern.setBackgroundResource(R.drawable.re1);
        } else if (playPattern == PLAY_SINGLE) {
            mPlayPattern.setBackgroundResource(R.drawable.repeat1);
        } else if (playPattern == PLAY_RANDOM) {
            mPlayPattern.setBackgroundResource(R.drawable.sj1);
        }
        //获取音乐列表
        //  getMusicListThread();
    }


    /**
     * 使用了一个子线程从数据库中获取音乐列表，
     * 并根据在用户信息中解析出的musicId，
     * 将歌曲信息也初始化到界面中
     */
    private void getMusicListThread() {
        new Thread() {
            @Override
            public void run() {
                try {
                    //  JSONArray result = RequestServlet.getMusicList();
                    Message msg = new Message();
                    msg.what = 2;
                    // msg.obj = result;
                    handler2.sendMessage(msg);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    private Handler handler2 = new Handler() {
        public void handleMessage(android.os.Message msg) {
            try {
                if (msg.what == 2) {
//                    sMusicList = (JSONArray) msg.obj;
//                    songNum = sMusicList.length();
//
//                    //根据用户数据和歌曲列表初始化有关歌曲的界面
//                    setMusicView(IsPlay.notPlay);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    /**
     * 将毫秒数转为时分秒
     */
    public String transformToHMS(int msT){
        SimpleDateFormat formatter = new SimpleDateFormat("mm:ss");
        //这里想要只保留分秒可以写成"mm:ss"------"HH:mm:ss"
        formatter.setTimeZone(TimeZone.getTimeZone("GMT+00:00"));
        String hms = formatter.format(msT);
        return hms;
    }

}
