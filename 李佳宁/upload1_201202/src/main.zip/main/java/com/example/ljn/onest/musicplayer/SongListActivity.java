package com.example.ljn.onest.musicplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class SongListActivity extends AppCompatActivity {

    private ImageView ivC;
    private TextView tvC;
    private TextView tvS;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_list);

        ivC = findViewById(R.id.iv_c);
        tvC = findViewById(R.id.tv_c);
        tvS  = findViewById(R.id.tv_shutdown);

        Intent i = getIntent();
        int playPattern = i.getIntExtra("play_pattern",0);
        int songT = i.getIntExtra("songsTotal",0);
        switch (playPattern){
            case 0:
                ivC.setImageResource(R.drawable.re1);
                tvC.setText("顺序播放（" + songT + "首）" );
                break;
            case 1:
                ivC.setImageResource(R.drawable.repeat1);
                tvC.setText("单曲循环（" + songT + "首）");
                break;
            case 2:
                ivC.setImageResource(R.drawable.sj1);
                tvC.setText("随机播放（" + songT + "首）");
                break;
        }

        tvS.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
