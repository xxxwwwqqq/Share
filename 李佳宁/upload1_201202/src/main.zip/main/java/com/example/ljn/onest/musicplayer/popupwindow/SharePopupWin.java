package com.example.ljn.onest.musicplayer.popupwindow;

import android.os.Bundle;

import com.example.ljn.onest.musicplayer.R;


import android.app.Activity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
public class SharePopupWin extends Activity implements View.OnClickListener {

    private ShareView sv1, sv2, sv3, sv4, sv5,sv6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_popup_win);
        sv1 = (ShareView) findViewById(R.id.sv_wx);
        sv2 = (ShareView) findViewById(R.id.sv_pyq);
        sv3 = (ShareView) findViewById(R.id.sv_qq);
        sv4 = (ShareView) findViewById(R.id.sv_wb);
        sv5 = (ShareView) findViewById(R.id.sv_lj);
        sv6 = (ShareView) findViewById(R.id.sv_kj);
        sv1.setTvShare("微信");
        sv2.setTvShare("朋友圈");
        sv3.setTvShare("QQ好友");
        sv4.setTvShare("新浪微博");
        sv5.setTvShare("复制链接");
        sv6.setTvShare("QQ空间");
        sv1.setIvShare(R.drawable.share_wx);
        sv2.setIvShare(R.drawable.share_pyq);
        sv3.setIvShare(R.drawable.share_qq);
        sv4.setIvShare(R.drawable.share_wb);
        sv5.setIvShare(R.drawable.c_lj1);
        sv6.setIvShare(R.drawable.share_kj);
        //添加事件监听
        sv1.setOnClickListener(this);
        sv2.setOnClickListener(this);
        sv3.setOnClickListener(this);
        sv4.setOnClickListener(this);
        sv5.setOnClickListener(this);
        sv6.setOnClickListener(this);

        findViewById(R.id.layout_share).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

    }
    //实现onTouchEvent触屏函数但点击屏幕时销毁本Activity
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        finish();
        return true;
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.sv_wx:
                Toast.makeText(SharePopupWin.this,"即将打开微信",Toast.LENGTH_SHORT).show();
                break;
            case R.id.sv_pyq:
                Toast.makeText(SharePopupWin.this,"即将打开朋友圈",Toast.LENGTH_SHORT).show();
                break;
            case R.id.sv_qq:
                Toast.makeText(SharePopupWin.this,"即将打开QQ",Toast.LENGTH_SHORT).show();
                break;
            case R.id.sv_wb:
                Toast.makeText(SharePopupWin.this,"即将打开微博",Toast.LENGTH_SHORT).show();
                break;
            case R.id.sv_lj:
                Toast.makeText(SharePopupWin.this,"复制链接成功",Toast.LENGTH_SHORT).show();
                break;
            case R.id.sv_kj:
                Toast.makeText(SharePopupWin.this,"即将打开qq空间",Toast.LENGTH_SHORT).show();

                break;
        }
        finish();
    }
}
