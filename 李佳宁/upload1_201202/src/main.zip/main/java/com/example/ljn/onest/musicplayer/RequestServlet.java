package com.example.ljn.onest.musicplayer;

import org.json.JSONObject;

public class RequestServlet {
    public static JSONObject getIntent() {
        JSONObject obj = new JSONObject();
        return obj;
    }

    public void getMusicList(){

    }
}
