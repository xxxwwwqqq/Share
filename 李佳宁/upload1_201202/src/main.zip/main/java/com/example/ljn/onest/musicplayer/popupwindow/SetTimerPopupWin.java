package com.example.ljn.onest.musicplayer.popupwindow;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.ljn.onest.musicplayer.R;

public class SetTimerPopupWin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_timer_popup_win);
    }
}
