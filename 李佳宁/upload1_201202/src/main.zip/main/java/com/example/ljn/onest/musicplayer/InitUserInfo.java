package com.example.ljn.onest.musicplayer;


import android.content.Intent;

import org.json.JSONObject;

public class InitUserInfo {
    private String account;    //账户
    private int musicId;   //歌曲id
    public int playPattern;  //播放模式

    //初始化用户信息
    private void initUserData(){
        Intent intent = new Intent();

        String userStr = intent.getStringExtra("result");
        JSONObject userData = RequestServlet.getIntent();
        account = userData.optString("account");
        musicId = userData.optInt("music_id");
        playPattern = userData.optInt("pattern");
    }
}
