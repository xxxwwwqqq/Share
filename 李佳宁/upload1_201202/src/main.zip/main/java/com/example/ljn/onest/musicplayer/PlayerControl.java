package com.example.ljn.onest.musicplayer;

public interface PlayerControl {
    /*
     *播放
     */
    void playOrPause();

    /*
     *播放上一首
     */
    void play_last();

    /*
     *播放下一首
     */
    void play_next();

    /*
     *停止播放
     */
    void stopPlay();

    /*
     *设置播放进度
     */
    void seekTo(int seek);
}
