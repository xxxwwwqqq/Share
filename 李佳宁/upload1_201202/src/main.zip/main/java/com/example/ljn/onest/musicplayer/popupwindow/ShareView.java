package com.example.ljn.onest.musicplayer.popupwindow;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.example.ljn.onest.musicplayer.R;

public class ShareView extends LinearLayout {
    private ImageView ivShare;
    private TextView tvShare;


    public ShareView(Context context) {
        super(context);
    }

    public ShareView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        //加载布局
        LayoutInflater.from(context).inflate(R.layout.share_ivtv_view,this);
        //获取控件
        ivShare = (ImageView)findViewById(R.id.iv_share);
        tvShare = (TextView)findViewById(R.id.tv_share);
    }

    //为图片和文字添加点击事件
    public void setOnclickIv(OnClickListener listener) {
        ivShare.setOnClickListener(listener);
    }
    public void setOnclickTv(OnClickListener listener) {
        tvShare.setOnClickListener(listener);
    }

    //设置图片资源

    public void setIvShare(int id) {
        ivShare.setImageResource(id);
    }

    //设置文字
    public void setTvShare(String str) {
        this.tvShare.setText(str);
    }

}
