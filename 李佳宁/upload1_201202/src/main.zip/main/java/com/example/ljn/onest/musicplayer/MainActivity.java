package com.example.ljn.onest.musicplayer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTabHost;

import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TabHost;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(getSupportActionBar() != null){
            getSupportActionBar().hide();
            getWindow().setFlags(
                    WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN
            );
        }
        //获取Fragment的引用
        FragmentTabHost fragmentTabHost = findViewById(android.R.id.tabhost);
        //初始化
        fragmentTabHost.setup(this,//环境上下文在main_activity中直接传this
                getSupportFragmentManager(),//管理多个Fragment对象的管理器
                android.R.id.tabcontent);//显示内容页面的控件的id
        //创建内容页面TabSpec的对象
        TabHost.TabSpec tab1 = fragmentTabHost.newTabSpec("first_tab")
                .setIndicator("休憩",getResources().getDrawable(R.drawable.m0));
        //Class参数：类名.class,对象.getClass()
        fragmentTabHost.addTab(tab1,
                FifthFragment.class,//FirstFragment类的Class对象
                null);//传递数据时使用，不需要传递数据直接传null
        TabHost.TabSpec tab2 = fragmentTabHost.newTabSpec("second_tab")
                .setIndicator( "页面二", getResources().getDrawable(R.drawable.m1));
        fragmentTabHost.addTab(tab2,FirstFragment.class,null);
        fragmentTabHost.setCurrentTab(0);
        //imageMap.get("first_tab").setImageResource(R.drawable.first1);
        //titleMap.get("first_tab").setTextColor(getResources().getColor(R.color.colorPrimary));
    }

}
