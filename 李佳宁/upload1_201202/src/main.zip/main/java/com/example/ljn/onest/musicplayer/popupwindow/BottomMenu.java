package com.example.ljn.onest.musicplayer.popupwindow;


import android.app.Activity;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Toast;

import com.example.ljn.onest.musicplayer.R;


public class BottomMenu implements OnClickListener, OnTouchListener {

    private PopupWindow popupWindow;
    private LinearLayout lmShare, lmAdd, lmBuy, lmBeisu, lmDel, lmRing, lmZhuti;
    private View mMenuView;
    private Activity mContext;
    private OnClickListener clickListener;

    public BottomMenu(Activity context, OnClickListener clickListener) {
        LayoutInflater inflater = LayoutInflater.from(context);
        this.clickListener = clickListener;
        mContext = context;
        mMenuView = inflater.inflate(R.layout.layout_popup_more, null);
        lmShare = mMenuView.findViewById(R.id.m_share);
        lmAdd = mMenuView.findViewById(R.id.m_add);
        lmBuy = mMenuView.findViewById(R.id.m_buy);
        lmBeisu = mMenuView.findViewById(R.id.m_beisu);
        lmDel = mMenuView.findViewById(R.id.m_del);
        lmRing = mMenuView.findViewById(R.id.m_ring);
        lmZhuti = mMenuView.findViewById(R.id.m_zhuti);

        lmZhuti.setOnClickListener(this);
        lmRing.setOnClickListener(this);
        lmBeisu.setOnClickListener(this);
        lmBuy.setOnClickListener(this);
        lmShare.setOnClickListener(this);
        lmAdd.setOnClickListener(this);
        lmDel.setOnClickListener(this);

        mMenuView.findViewById(R.id.vol_d).setOnClickListener(this);
        mMenuView.findViewById(R.id.vol_u).setOnClickListener(this);
        mMenuView.findViewById(R.id.tv_m_cancel).setOnClickListener(this);

        popupWindow = new PopupWindow(mMenuView, LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, true);
        popupWindow.setAnimationStyle(R.style.popwin_anim_style);
        ColorDrawable dw = new ColorDrawable(context.getResources().getColor(R.color.ccc));
        popupWindow.setBackgroundDrawable(dw);
        popupWindow.setClippingEnabled(true);
        mMenuView.setOnTouchListener(this);
    }

    /**
     * 显示菜单
     */
    public void show() {
        //得到当前activity的rootView
        View rootView = ((ViewGroup) mContext.findViewById(android.R.id.content)).getChildAt(0);
        popupWindow.showAtLocation(rootView, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
    }

    @Override
    public boolean onTouch(View arg0, MotionEvent event) {
        int height = mMenuView.findViewById(R.id.layout_more).getTop();
        int y = (int) event.getY();
        if (event.getAction() == MotionEvent.ACTION_UP) {
            if (y < height) {
                popupWindow.dismiss();
            }
        }
        return true;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.m_share:
                Toast.makeText(mContext.getApplicationContext(), "即将打开qq空间", Toast.LENGTH_SHORT).show();
                break;
            case R.id.m_add:
                break;
            case R.id.m_buy:
                break;
            case R.id.m_beisu:
                break;

            case R.id.m_ring:
                break;
            case R.id.m_zhuti:
                break;
            case R.id.m_del:
                break;
            case R.id.vol_d:
                break;
            case R.id.vol_u:
                break;
            case R.id.tv_m_cancel:
                popupWindow.dismiss();
                break;
        }
        popupWindow.dismiss();
    }
}
