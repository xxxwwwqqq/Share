package com.example.ljn.onest.musicplayer.popupwindow;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import com.example.ljn.onest.musicplayer.R;

public class FixTimerPopupWindow extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fix_time_popup_window);

        Log.e("ljn","ll");
        setListener();
        findViewById(R.id.layout_timer).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        // getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private void setListener() {
        findViewById(R.id.t_no).setOnClickListener(this);
        findViewById(R.id.t_cur).setOnClickListener(this);
        findViewById(R.id.t_cur2).setOnClickListener(this);
        findViewById(R.id.t_cur3).setOnClickListener(this);
        findViewById(R.id.t_10).setOnClickListener(this);

        Log.e("ljn","获取控件");
        findViewById(R.id.t_20).setOnClickListener(this);
        findViewById(R.id.t_30).setOnClickListener(this);
        findViewById(R.id.t_60).setOnClickListener(this);
        findViewById(R.id.t_90).setOnClickListener(this);
        findViewById(R.id.t_diy).setOnClickListener(this);

        findViewById(R.id.tv_f_dld).setOnClickListener(this);
    }

    //实现onTouchEvent触屏函数但点击屏幕时销毁本Activity
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        finish();
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.t_no:

                break;
            case R.id.t_cur:
                break;
            case R.id.t_cur2:
                break;
            case R.id.t_cur3:
                break;
            case R.id.t_10:
                break;

            case R.id.t_20:
                break;
            case R.id.t_30:
                break;
            case R.id.t_60:
                break;
            case R.id.t_90:
                break;
            case R.id.t_diy:
                Intent iDiy = new Intent();
                iDiy.setClass(FixTimerPopupWindow.this, SetTimerPopupWin.class);
                startActivity(iDiy);
                break;
            case R.id.tv_f_dld:
                finish();
        }
        finish();
    }


}
