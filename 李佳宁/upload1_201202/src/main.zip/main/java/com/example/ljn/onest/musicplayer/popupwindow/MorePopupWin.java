package com.example.ljn.onest.musicplayer.popupwindow;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.ljn.onest.musicplayer.R;

public class MorePopupWin extends AppCompatActivity {

    ShareView svRing;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_popup_win);
        svRing = findViewById(R.id.sv_ring);
        svRing.setIvShare(R.drawable.ring);
        svRing.setTvShare("设为铃声");
    }
}
