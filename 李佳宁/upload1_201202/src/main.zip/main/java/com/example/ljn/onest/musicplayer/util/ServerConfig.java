package com.example.ljn.onest.musicplayer.util;

public class ServerConfig {
    public final static String SERVER_ADDR = "";
    public final static String NET_HOME = "Ch12NetworkServerDemo";
}
